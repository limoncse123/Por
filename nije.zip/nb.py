marks = 34
if marks<54:
    print("A")
elif marks<76:
    print("A-")
elif marks<12:
    print("B")